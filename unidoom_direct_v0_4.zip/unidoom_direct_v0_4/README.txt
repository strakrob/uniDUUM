UniDoom Direct v0.4 — Two sectors, keys, secrets, navigation and backbuffer
======================================================================

Load unidoom_direct_v0_4.mzf with the loader used for the earlier demos.
The earlier MZFs and source ZIPs are preserved. The current doom_direct/
source folder builds v0.4.

Explore two 32x24 sectors, recover the blue key and cyan data core, then
return to the green exit. The key opens the blue-locked western blast door
and is required at the exit. Press N after winning to enter the next sector,
or use 1/2 to select either sector directly. P plays through the current
sector, including its secret cache, combat, key, core and return route.

FEATURES

  - Two different connected sectors, with shared original 16-colour artwork
  - Eight patrolling drones, activated by line of sight, with reverse-grid
    navigation around walls and three physical sprite animation frames
  - A collectible blue key, locked door, and a hidden supply wall in each map
  - Secret rewards: 24 rounds and 20 health, capped at 99 ammo / 100 health;
    a secret can be opened and rewarded only once per sector visit
  - Pistol and three-pellet shotgun, hit sparks/blood, and 16 bounded particles
  - Animated reactor textures and emissive plasma/lights
  - Perspective textured floor/ceiling, partial lifting doors, clipped
    billboards, collision, hitscan, weapon effects, HUD and minimap
  - Original looping metal music and eight PSG sound effects
  - DDQD god mode, ARM backbuffer, and direct UniCard VGA presentation

All assets are embedded; no WAD or external game files are needed. Maps
and artwork are PackBits-compressed in the uploaded image and unpacked into
ARM RAM. Art remains packed 4 bpp after decompression. Guided paths use two
bits per cell-to-cell step. This makes the additions fit the original
loader bound without overwriting firmware memory.

CONTROLS

  ARROWS / WASD   Walk forward/back; turn left/right
  Q / E           Strafe left/right
  SPACE           Fire; hold for repeated shots
  V               Switch pistol / shotgun
  F               Use a nearby door or secret wall
  M               Toggle minimap
  P               Start / stop guided play-through of the current sector
  B               Toggle music; enabling it restarts the loop
  L               Toggle light cone
  Z               Toggle running
  1 / 2           Select and restart sector 1 / 2
  N               Next sector after mission complete
  R / ESC         Restart the current sector
  DDQD            Toggle god mode; IDDQD also works

The shotgun costs two rounds and has an eight-frame cooldown; its three
pellets spread around the crosshair. The pistol costs one round and has a
four-frame cooldown. God mode restores 100 health and prevents damage;
ammo is still consumed. Reset/sector changes clear keys, secret rewards,
particles and god mode. Music continues independently of sector changes.
Movement takes over from the guided tour.

The blue key is at (9.5, 6.5), core at (28.5, 3.5), and exit at (2.5, 13.5).
The supply wall is tile (5,10): use F from an adjacent corridor.
Opening it also creates a shortcut. These placements are shared
between the two sectors; the surrounding materials and eastern/southern
room layouts differ. The blue lock is the door at tile (6,3).

ARM FRAMEBUFFER AND MEMORY

The Sharp CPU performs no framebuffer transfers or VRAM reads/writes.
ARM renders into the former private framebuffer at 0x20028000, then copies
only the visible pixels into the live UniCard VGA buffer at 0x10001F80.
This is an ARM-to-ARM-memory copy; Sharp VRAM is bypassed entirely.

VGA plane slots:
  P1 / colour bit 0   0x10001F80 .. 0x10003F7F
  P2 / colour bit 1   0x10003F80 .. 0x10005F7F
  P3 / colour bit 2   0x10005F80 .. 0x10007F7F
  P4 / colour bit 3   0x10007F80 .. 0x10009F7F

Each slot has an 8192-byte stride. Exactly 8000 visible bytes per plane are
written: 200 rows of 40 bytes, leftmost pixel in the least significant bit.
The 192 padding bytes per plane remain untouched in both buffers. An ARM
DMB follows presentation before returning to firmware.

The backbuffer occupies 0x20028000..0x2002FFFF. The linker keeps code,
decoded assets, maps, game state and navigation below 0x20028000, and checks
the backbuffer remains inside the original 64 KB OpenCPU user window.

MZF file: 19237 bytes; loaded image: 19109 bytes at 3000h..7AA4h.
Free under the current 8000h loader limit: 1371 bytes.
ARM code/assets/state: 30504 bytes; backbuffer: 32768 bytes.
Free before the backbuffer: 2264 bytes. See MEMORY.txt and build/memory.json.

This uses the supplied VGA address and original planar layout. Physical
UniCard firmware must scan that memory and allow ARM to own its contents.
The backbuffer prevents the VGA buffer showing an intermediate clear and
rasterization, but the final visible copy can still overlap scanout; a
firmware-supported buffer swap/synchronization is needed for guaranteed
tear-free output. Physical Sharp/UniCard operation remains untested.

HARNESS, TIMING AND SOUND

The Z80 configures GDG mode/palette/scroll, uploads and verifies ARM once,
samples the full keyboard at 50 Hz, sends input and calls OpenCPU. It reads
one sound-event byte per frame; no CEh framebuffer-readback command is used.
The Sharp CPU VRAM window stays disabled. Load/execute remains 3000h.

The host starts frames after four 50 Hz interrupts: a target ceiling of
12.5 FPS, with lower rates if rendering is slower. Physics advances once
per rendered frame. This is pacing, not a measured hardware frame rate.

OpenCPU header at 0x20020000:
  +00h   Thumb entry pointer
  +04h   Live VGA buffer pointer, 0x10001F80
  +08h   Key event
  +09h   Native initialization flag
  +0Ah   Held-button mask
  +0Bh   Sound-event mask

Held bits: 01 forward, 02 backward, 04 left, 08 right, 10 strafe left,
20 strafe right, 40 fire, 80 use. DDQD is recognized on Z80 key-down
transitions and delivered as event FEh, retaining the cheat during a busy
ARM call. Short taps are latched; simultaneous movement/actions work.

Steel Circuit is an original 150 BPM, eight-bar PSG metal loop, 12.8 seconds
long, inspired by early Doom's driving feel. It is not an E1M1 transcription.
Tone channels 1/2 play lead/bass, and percussion uses the shared noise
channel. Game effects own tone 0 and take priority over percussion; the
other music voices continue. Playback runs on the Z80 at 50 Hz while ARM
is busy. B mutes music without muting effects.

Effects, lowest to highest priority: shot, hit, drone destruction, player
hurt, door, pickup/secret, victory and god mode. Envelopes finish muted;
PSG writes have recovery delays. Upload mismatch or ARM timeout disables
interrupts, silences every PSG channel and requests a red border.
The Sharp SN76489 is written on port F2h, as documented in section 4-6:
  https://www.idealine.info/sharpmz/mz-800/download/sm800.pdf

BUILD AND VERIFY

From the workspace/package root:
  python3 doom_direct/tools/build.py
  python3 doom_direct/tools/verify.py
  python3 doom_direct/tools/preview_extras.py

Workspace Makefile targets: make doom-direct / make verify-doom-direct.
Inside doom_direct/: make / make verify.

Build requires Python 3, clang with ARM target, lld, llvm-objcopy, llvm-nm
and pasmo. UNIDOOM_DIRECT_LLD can select the linker. The original hash-
checked unifractal_v0_2.mzf supplies the keyboard table. Asset/music/sound
generation uses Python's standard library. Verification additionally needs
Unicorn 2.1+, numpy, Pillow and libz80ex1; UNIDOOM_DIRECT_Z80EX can select
the Z80 library. Existing temporary tool locations are recognized.

The verifier checks the actual assembled Z80 and Cortex-M4 code:
  - 93 integrated frames with exact native C framebuffer/game-state matches
  - Backbuffer/live VGA equality; complete raster before the first VGA write
  - Exactly 32000 bytes presented, with both buffers' padding untouched
  - Code/state, backbuffer and CCM guards; no writes to unowned CCM
  - Zero Sharp VRAM access and no Z80 framebuffer copies
  - Exact moving-drone positions and decoded art between ARM and native C
  - Keys, locked doors, secret rewards, shotgun and sector changes via Z80
  - Held/multiple keys, fast DDQD, upload mismatch and busy timeout
  - 24 independently computed ray-depth views across both sectors
  - Partial-door sprite clipping, collision, blocked shots and god mode
  - Independent decompressed map/texture checks and 1536 BFS distances
  - A drone navigating around a wall; all drones collision-safe in both tours
  - Single secret reward, particle expiry and three distinct walk frames
  - Both complete guided tours: 957 and 996 frames, with key, secret and core
  - All eight effects and two complete byte-verified music loops (1280 ticks)
  - Music mute/restart, held B, sound-effect priority and PSG recovery delays

Results/hashes: build/verification.json. Budget: build/memory.json.
These are CPU/protocol simulations; hardware and firmware timing still need
physical testing.

PREVIEWS AND SOURCE

previews/boot.png, door.png and sector2.png come from emulated Z80/ARM.
Other views and GIFs use the same renderer compiled natively. tour.gif and
tour2.gif are accelerated play-throughs; drones.gif has a stationary camera.
textures.png is the material atlas; shotgun.png, secret.png and god.png show
the corresponding features. RGBI levels approximate the physical display.

music.wav is synthesized from the verified Z80 PSG command stream;
sounds.wav auditions all effects. They approximate chip waveforms and are
not recordings of physical hardware. sounds.json gives effect start times.

src/raycaster.c: renderer, simulation, navigation, controls and native hooks.
src/host.asm: Z80 upload/call/input, music, sound and frame pacing.
src/unicard.ld and unicard_header.S: memory bounds and ABI.
src/assets.h, font.h and sine.h: compressed assets, font and sine lookup.
tools/build.py: compilation, linked-symbol budget and MZF packaging.
tools/generate_assets.py, generate_music.py, generate_sounds.py: content.
tools/verify.py, verify_scene.py: CPU, bus, independent scene/game checks.
tools/preview_extras.py: optional native animation and audio auditions.

Transport and keyboard mapping build on NOBOMI-SOFTWARE's supplied
unifractal_v0_2.mzf and earlier UniGray/UniCube/UniDoom projects here.
