"""Compose an original compact PSG metal loop, with no imported game music.

150 BPM, 16th notes: 5 ticks at 50 Hz, 8 bars = 12.8 seconds. Two tone
voices and percussion; tone 0 is reserved for game effects. Every three-byte
step stores lead note index, bass note index, and percussion instrument.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
CLOCK=3546895
TICKS=5
# Original syncopated motifs. These are not a transcription of Doom's E1M1.
BASS=[
 [52,0,59,52,0,55,54,0,52,59,0,57,55,0,54,50],
 [52,52,0,59,55,0,54,52,0,57,59,0,55,54,0,52],
 [55,0,62,55,0,59,57,0,55,62,0,60,59,0,57,54],
 [54,54,0,61,57,0,59,54,0,52,57,0,59,57,54,0],
]
LEAD=[
 [0,76,0,79,83,0,81,79,0,78,0,74,76,0,0,71],
 [76,0,83,0,81,79,0,78,76,0,74,0,71,74,78,0],
 [79,0,83,86,0,83,81,0,79,0,78,74,0,76,0,78],
 [78,81,0,85,83,0,81,78,0,76,74,0,78,74,71,0],
]

def generate():
    steps=[]
    for bar in range(8):
        pattern=bar%4
        for step in range(16):
            lead=LEAD[pattern][step]
            # First half exposes the rhythm; the second half opens the lead.
            if bar<4 and step%4 not in (1,2):lead=0
            percussion=1 if step in (0,6,8,14) else 2 if step in (4,12) else 3 if step%2==0 else 0
            steps.append([lead,BASS[pattern][step],percussion])
    notes=sorted({0}|{n for step in steps for n in step[:2]})
    note_index={note:i for i,note in enumerate(notes)}
    dividers=[0 if note==0 else round(CLOCK/(32*(440*2**((note-69)/12)))) for note in notes]
    assert all(1<=d<=1023 for d in dividers[1:])
    encoded=[[note_index[lead],note_index[bass],percussion] for lead,bass,percussion in steps]
    out=['; Original music: Steel Circuit. 150 BPM; 8 bars; 12.8 second loop.',
         'MUSIC_STEP_TICKS equ '+str(TICKS),'music_data_start:',
         'music_notes: dw '+','.join(map(str,dividers)), 'music_song:']
    out+=['db '+','.join(map(str,row)) for row in encoded]
    out+=['music_song_end:', 'music_data_end:']
    (ROOT/'build/music.inc').write_text('\n'.join(out)+'\n')
    manifest={'title':'Steel Circuit','original_composition':True,'bpm':150,'ticks_per_step':TICKS,
              'tick_hz':50,'steps':encoded,'midi_notes':notes,'dividers':dividers,
              'loop_seconds':len(steps)*TICKS/50,'voices':[1,2],
              'percussion':{'0':[0xe4,15],'1':[0xe2,7],'2':[0xe5,8],'3':[0xe4,12]},
              'data_bytes':len(dividers)*2+len(steps)*3}
    (ROOT/'build/music.json').write_text(json.dumps(manifest,indent=2)+'\n')
