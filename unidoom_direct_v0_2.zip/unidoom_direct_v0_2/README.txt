UniDoom Direct v0.2 — Expanded sector, drones and PSG sound
==================================================

Load unidoom_direct_v0_2.mzf using the same loader as the earlier demos.
This is a separate project based on UniDoom v0.1. The earlier Doom project
and its MZF are preserved.

NEW IN v0.2

  - A 32x24-cell map: three times the area of the original 16x16 level,
    with reactor wings, connected rooms, a southern hall and a larger minimap.
  - Eight 32x32 material textures, each using all 16 RGBI colours: bevelled
    bulkheads, oxidised brick, hazard machinery, plasma columns, blast doors,
    an exit panel, recessed floor plates and illuminated ceiling conduits.
    Textures and sprites are packed as two 4-bit texels per byte.
  - Eight drones that patrol, turn at walls, and chase on line of sight.
    Drones stop at closed doors; doors avoid closing around living drones.
  - Eight PSG effects: shot, hit, destruction, player hurt, door, pickup,
    mission complete and god-mode toggle. Envelopes run at 50 Hz on the Z80.
  - Type DDQD to toggle god mode. The HUD shows GOD and a confirmation.
    Turning it on restores 100 health and prevents damage; ammo is consumed
    normally. Type DDQD again to restore damage, or reset to clear the cheat.
  - Exactly 8000 visible bytes are drawn per plane; padding stays untouched.

The ARM renderer writes every pixel directly to the address you supplied,
0x10001F80. The Z80 no longer reads back 32 KB each frame or copies it into
Sharp VRAM. There is no Sharp VRAM startup clear either. The rendered image
is intended for UniCard's VGA output; Sharp's own video output receives no
rendered frames from this program.

The supplied address is treated as a live planar buffer, with the same
layout as the original harness:

  Plane 1 / colour bit 0    0x10001F80 .. 0x10003F7F
  Plane 2 / colour bit 1    0x10003F80 .. 0x10005F7F
  Plane 3 / colour bit 2    0x10005F80 .. 0x10007F7F
  Plane 4 / colour bit 3    0x10007F80 .. 0x10009F7F

Each plane has an 8192-byte stride, with 8000 visible bytes: 200 rows of
40 bytes, 320 pixels per row, leftmost pixel in the least significant bit.
The remaining 192 bytes per plane are left untouched. These are allocation
strides, not a requirement for 8192 contiguous visible bytes. The four slots
span 32768 bytes; 0x10009F80 is their exclusive end address. Visible image
data totals 32000 bytes. The 8192-byte plane stride remains configurable in
the renderer if your finder reports a different physical plane layout.

This depends on your UniCard firmware using that exact address and layout
for VGA scanout, and allowing OpenCPU to own those pixels without replacing
them from Sharp VRAM. The address comes from your measurement, rather than
a new hardware detection performed by this project. CPU/protocol emulation
passes, but this build has not been run on a physical Sharp/UniCard.

DIRECT RENDERING

  src/unicard.ld defines __video_buffer = 0x10001F80 and checks that all
  32768 bytes fit in the 64 KB CCM RAM address window.

  src/raycaster.c uses volatile byte reads/writes at __video_buffer for
  clearing, scene rendering, sprites, weapon, HUD and minimap. A DMB follows
  rendering before returning to firmware. No full-screen staging buffer is
  allocated on ARM; the old 0x20028000 staging area is unused.

  src/host.asm uploads and verifies the ARM payload once. Each frame sends
  a key event and held-button mask, calls the Thumb entry, and waits for
  completion. It then reads one sound-event byte. It contains no framebuffer
  copy routine and issues no CEh
  framebuffer-readback command. The Sharp CPU VRAM window stays disabled.

GDG mode, palette and scroll registers are still configured through I/O,
so UniCard can interpret the buffer as 320x200 in 16 colours. This bypasses
Sharp VRAM drawing, while retaining the existing OpenCPU interface on
ports 50h/51h and the Sharp keyboard interrupt service.

The ARM code/state starts at 0x20020000. Its original ABI is retained:

  0x20020000    Thumb entry pointer
  0x20020004    Direct framebuffer pointer: 0x10001F80
  0x20020008    Key event byte
  0x20020009    Initialization flag
  0x2002000A    Held-button mask
  0x2002000B    Sound event bitmask, reset by ARM on every frame

Sound bits in increasing priority order: 01h shot, 02h hit, 04h destruction,
08h hurt, 10h door, 20h pickup, 40h victory, 80h god mode. If several occur
together, the host plays the highest-priority effect. The frame's only new
readback is this single event byte; framebuffer pixels remain ARM-local.

The host writes the Sharp SN76489 PSG on port F2h, using one tone channel
and white noise. Channels 1/2 are silenced at startup, all effects end muted,
and PSG writes have explicit recovery delays. The existing 50 Hz interrupt
updates sound while ARM is busy; it does not busy-wait for an entire effect.
Sound comes from the Sharp's audio output, not a new UniCard audio interface.
The port is documented in Sharp's service manual, section 4-6:
  https://www.idealine.info/sharpmz/mz-800/download/sm800.pdf

The MZF load/execute address remains 3000h. Upload mismatch or ARM timeout
stops the host and requests a red border.

FRAME PACING

Without the Z80 copy, simulation would otherwise run as fast as rendering
allows. The host now starts a frame after four 50 Hz keyboard/VBLANK ticks:
up to 12.5 FPS, with lower rates if rendering takes longer. FRAME_DIVISOR in
src/host.asm controls this interval. Inputs are sampled on every interrupt;
short key taps remain latched while the ARM runs. This limits simulation
speed; it is not a measured hardware frame-rate claim or a scanout lock.

This is single-buffer drawing. VGA may scan the image while ARM clears or
redraws it, so tearing or flicker is possible. A firmware-specific buffer
swap or scanout synchronization would be needed to eliminate that effect.

DEMO AND CONTROLS

Explore the sector, shoot security drones, collect the cyan data core at
(28.5, 3.5) in the northeast reactor wing, and return to the green exit at
(2.5, 13.5) in the original western sector. You start with 72 rounds.
All textures, sprites and level data are embedded in the MZF; no WAD needed.

  UP / W          Walk forward
  DOWN / S        Walk backward
  LEFT / A        Turn left
  RIGHT / D       Turn right
  Q / E           Strafe left / right
  SPACE           Fire; hold for repeated shots
  F               Open / close the nearest door
  M               Toggle minimap
  P               Start / stop a guided play-through
  L               Toggle the light cone
  Z               Toggle running
  R / ESC         Restart
  DDQD            Toggle god mode (type the four letters)

Movement, turning, strafing and shooting can be combined. Movement keys
take over from the guided tour. Starting the tour begins a fresh level.
The Z80 recognizes DDQD on key-down transitions at 50 Hz and latches event
FEh for ARM, so fast typing during a native call does not lose the sequence.
Normal D/Q movement bindings still apply while typing. IDDQD also works:
its initial I is ignored before the requested DDQD sequence.

The ARM renderer retains 160 DDA rays, perspective textured floors and
ceilings, distance lighting, rising doors, clipped billboard sprites,
collision, hitscan shooting, weapon effects, HUD and minimap. The view is
160x160 samples doubled horizontally inside a 320x160 viewport; text uses
the full 320-pixel resolution. Physics advances once per rendered frame.

BUILD AND VERIFY

From the workspace or extracted package root:
  python3 doom_direct/tools/build.py
  python3 doom_direct/tools/verify.py

From the original workspace:
  make doom-direct
  make verify-doom-direct

From doom_direct/:
  make
  make verify

Build dependencies: Python 3, clang with ARM target, lld, llvm-objcopy,
pasmo. UNIDOOM_DIRECT_LLD can select a linker. The original, hash-checked
unifractal_v0_2.mzf supplies the keyboard table. Generated textures and
map assets use Python's standard library.

Verification additionally needs Unicorn 2.1+, numpy, Pillow and libz80ex1.
UNIDOOM_DIRECT_Z80EX can select the Z80 library. The build/verify tools also
recognize the temporary tool installations used for the earlier projects.

Verification executes the actual assembled Z80 host and Cortex-M4 payload:
  - 76 integrated frames, exactly matching native C pixels and game state
  - All eight moving drone positions compared bit for bit between ARM and C
  - Direct CCM framebuffer, with guards on both sides
  - Entire CCM region outside the framebuffer unchanged
  - Old 32 KB SRAM framebuffer left untouched
  - Zero Sharp VRAM reads/writes and zero CEh framebuffer transfers
  - Four-interrupt frame pacing, held/multiple keys and retained short taps
  - DDQD on/off through the Sharp keyboard and during a busy ARM interval
  - All eight PSG sequences and their priority, recovery delays and final mute
  - Exactly 8000 visible bytes per plane; all 192 padding bytes unchanged
  - Opening doors, walking through, and safe closing around the player
  - Dirty RAM initialization, upload mismatch and bounded busy timeout

Independent scene checks cover twelve ray-depth views in both old and new
sectors, partial door/sprite occlusion, collision, blocked shots, objectives
and a complete guided play-through. Drone wall collision, god-mode damage
immunity, restoring damage after DDQD, and all 16 colours in every material
are checked. Results, tour length and hashes are in build/verification.json.

previews/boot.png and door.png are decoded from the direct CCM framebuffer
after executing both emulated CPUs. The other previews use the native C
renderer. The GIF is accelerated; RGBI colours approximate the display.
previews/textures.png shows the material atlas; god.png shows the cheat HUD.
previews/drones.gif is a fixed-camera native animation at the target cadence.
previews/sounds.wav is an approximate synthesized audition, in this order:
shot, hit, kill, hurt, door, pickup, victory, god mode. It is not a recording
of physical hardware; previews/sounds.json lists the effect start times.
Regenerate these optional extras after verification with:
  python3 doom_direct/tools/preview_extras.py

FILES

  src/raycaster.c          ARM renderer, game logic, input and native hooks
  src/host.asm             Z80 upload/call/input host and frame pacing
  src/unicard.ld           Direct framebuffer address and RAM limits
  src/unicard_header.S     OpenCPU header
  src/assets.h             Generated level, textures and sprites
  src/font.h, sine.h       Font and generated sine lookup
  tools/build.py           Compile and package the MZF
  tools/generate_assets.py Procedural assets and map validation
  tools/generate_sounds.py PSG envelopes and generated assembly table
  tools/preview_extras.py  Native drone GIF and approximate sound audition
  tools/verify.py          Z80/ARM/direct-buffer integration checks
  tools/verify_scene.py    Independent scene checks and previews

The transport and keyboard mapping build on NOBOMI-SOFTWARE's supplied
unifractal_v0_2.mzf and the UniGray/UniCube/UniDoom work in this workspace.
