#!/usr/bin/env python3
"""Optional native drone animation and approximate PSG effect audition WAV.
Run after verify.py creates native.so. These previews are not hardware captures.
"""
import ctypes as ct
import json
from pathlib import Path
import wave
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parent.parent
n=ct.CDLL(str(ROOT/'build/native.so'))
n.native_frame.restype=ct.POINTER(ct.c_uint8)
n.native_cold();n.native_key(0,0)
palette=[]
for c in range(16):
    low,high=(85,255) if c&8 else (0,170)
    palette.extend([high if c&2 else low,high if c&4 else low,high if c&1 else low])
frames=[]
for tick in range(96):
    n.native_key(0,0)
    if tick%3:continue
    data=np.frombuffer(ct.string_at(n.native_frame(),32768),dtype=np.uint8).reshape(4,8192)[:,:8000]
    bits=np.unpackbits(data,axis=1,bitorder='little').reshape(4,200,320)
    pixels=np.sum(bits*np.array([1,2,4,8])[:,None,None],axis=0).astype(np.uint8)
    im=Image.fromarray(pixels,'P');im.putpalette(palette+[0]*(768-len(palette)))
    frames.append(im.resize((640,400),Image.Resampling.NEAREST))
frames[0].save(ROOT/'previews/drones.gif',save_all=True,append_images=frames[1:],duration=240,loop=0,optimize=False)
# Approximate tone and white noise from the same divider/attenuation envelopes
# sent by the Z80, with 0.2 seconds of silence between effects.
sounds=json.loads((ROOT/'build/sounds.json').read_text())
rate=22050;rng=np.random.default_rng(1234);audio=[];markers=[]
for name,sequence in sounds.items():
    markers.append({'effect':name,'seconds':sum(len(a) for a in audio)/rate})
    phase=0.0
    for lo,hi,tone,noise in sequence:
        divider=max(1,lo+(hi<<8));frequency=3546895/(32*divider)
        t=np.arange(rate//50)/rate
        wave_tone=np.where(np.mod(phase+t*frequency,1)<.5,1.0,-1.0)
        phase=(phase+len(t)*frequency/rate)%1
        gain=lambda a:0 if a>=15 else 10**(-a/10)
        audio.append((wave_tone*gain(tone)+rng.choice([-1.,1.],len(t))*gain(noise))*.35)
    audio.append(np.zeros(rate//5))
raw=np.clip(np.concatenate(audio)*32767,-32768,32767).astype('<i2').tobytes()
with wave.open(str(ROOT/'previews/sounds.wav'),'wb') as out:
    out.setnchannels(1);out.setsampwidth(2);out.setframerate(rate);out.writeframes(raw)
(ROOT/'previews/sounds.json').write_text(json.dumps(markers,indent=2)+'\n')
print('Wrote native drones.gif and approximate sounds.wav; not physical captures.')
