.syntax unified
.thumb
.section .header,"a",%progbits
.word doom_direct_entry
.word __video_buffer
.global abi
abi:
.byte 0,0,0,0
