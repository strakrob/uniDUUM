UniDoom Direct v0.1 — UniCard VGA framebuffer edition
==================================================

Load unidoom_direct_v0_1.mzf using the same loader as the earlier demos.
This is a separate project based on UniDoom v0.1. The earlier Doom project
and its MZF are preserved.

The ARM renderer writes every pixel directly to the address you supplied,
0x10001F80. The Z80 no longer reads back 32 KB each frame or copies it into
Sharp VRAM. There is no Sharp VRAM startup clear either. The rendered image
is intended for UniCard's VGA output; Sharp's own video output receives no
rendered frames from this program.

The supplied address is treated as a live planar buffer, with the same
layout as the original harness:

  Plane 1 / colour bit 0    0x10001F80 .. 0x10003F7F
  Plane 2 / colour bit 1    0x10003F80 .. 0x10005F7F
  Plane 3 / colour bit 2    0x10005F80 .. 0x10007F7F
  Plane 4 / colour bit 3    0x10007F80 .. 0x10009F7F

Each plane has an 8192-byte stride, with 8000 visible bytes: 200 rows of
40 bytes, 320 pixels per row, leftmost pixel in the least significant bit.
The remaining 192 bytes per plane are cleared as padding. The total buffer
is 32768 bytes; 0x10009F80 is its exclusive end address.

This depends on your UniCard firmware using that exact address and layout
for VGA scanout, and allowing OpenCPU to own those pixels without replacing
them from Sharp VRAM. The address comes from your measurement, rather than
a new hardware detection performed by this project. CPU/protocol emulation
passes, but this build has not been run on a physical Sharp/UniCard.

DIRECT RENDERING

  src/unicard.ld defines __video_buffer = 0x10001F80 and checks that all
  32768 bytes fit in the 64 KB CCM RAM address window.

  src/raycaster.c uses volatile byte reads/writes at __video_buffer for
  clearing, scene rendering, sprites, weapon, HUD and minimap. A DMB follows
  rendering before returning to firmware. No full-screen staging buffer is
  allocated on ARM; the old 0x20028000 staging area is unused.

  src/host.asm uploads and verifies the ARM payload once. Each frame sends
  a key event and held-button mask, calls the Thumb entry, and waits for
  completion. It contains no framebuffer-copy routine and issues no CEh
  framebuffer-readback command. The Sharp CPU VRAM window stays disabled.

GDG mode, palette and scroll registers are still configured through I/O,
so UniCard can interpret the buffer as 320x200 in 16 colours. This bypasses
Sharp VRAM drawing, while retaining the existing OpenCPU interface on
ports 50h/51h and the Sharp keyboard interrupt service.

The ARM code/state starts at 0x20020000. Its original ABI is retained:

  0x20020000    Thumb entry pointer
  0x20020004    Direct framebuffer pointer: 0x10001F80
  0x20020008    Key event byte
  0x20020009    Initialization flag
  0x2002000A    Held-button mask
  0x2002000B    Reserved

The MZF load/execute address remains 3000h. Upload mismatch or ARM timeout
stops the host and requests a red border.

FRAME PACING

Without the Z80 copy, simulation would otherwise run as fast as rendering
allows. The host now starts a frame after four 50 Hz keyboard/VBLANK ticks:
up to 12.5 FPS, with lower rates if rendering takes longer. FRAME_DIVISOR in
src/host.asm controls this interval. Inputs are sampled on every interrupt;
short key taps remain latched while the ARM runs. This limits simulation
speed; it is not a measured hardware frame-rate claim or a scanout lock.

This is single-buffer drawing. VGA may scan the image while ARM clears or
redraws it, so tearing or flicker is possible. A firmware-specific buffer
swap or scanout synchronization would be needed to eliminate that effect.

DEMO AND CONTROLS

Explore the sector, shoot security drones, collect the cyan data core in
the northeast room, and return to the green exit in the southwest corner.
All textures, sprites and level data are embedded in the MZF; no WAD needed.

  UP / W          Walk forward
  DOWN / S        Walk backward
  LEFT / A        Turn left
  RIGHT / D       Turn right
  Q / E           Strafe left / right
  SPACE           Fire; hold for repeated shots
  F               Open / close the nearest door
  M               Toggle minimap
  P               Start / stop a guided play-through
  L               Toggle the light cone
  Z               Toggle running
  R / ESC         Restart

Movement, turning, strafing and shooting can be combined. Movement keys
take over from the guided tour. Starting the tour begins a fresh level.

The ARM renderer retains 160 DDA rays, perspective textured floors and
ceilings, distance lighting, rising doors, clipped billboard sprites,
collision, hitscan shooting, weapon effects, HUD and minimap. The view is
160x160 samples doubled horizontally inside a 320x160 viewport; text uses
the full 320-pixel resolution. Physics advances once per rendered frame.

BUILD AND VERIFY

From the workspace or extracted package root:
  python3 doom_direct/tools/build.py
  python3 doom_direct/tools/verify.py

From the original workspace:
  make doom-direct
  make verify-doom-direct

From doom_direct/:
  make
  make verify

Build dependencies: Python 3, clang with ARM target, lld, llvm-objcopy,
pasmo. UNIDOOM_DIRECT_LLD can select a linker. The original, hash-checked
unifractal_v0_2.mzf supplies the keyboard table. Generated textures and
map assets use Python's standard library.

Verification additionally needs Unicorn 2.1+, numpy, Pillow and libz80ex1.
UNIDOOM_DIRECT_Z80EX can select the Z80 library. The build/verify tools also
recognize the temporary tool installations used for the earlier projects.

Verification executes the actual assembled Z80 host and Cortex-M4 payload:
  - 60 integrated frames, exactly matching native C pixels and game state
  - Direct CCM framebuffer, with guards on both sides
  - Entire CCM region outside the framebuffer unchanged
  - Old 32 KB SRAM framebuffer left untouched
  - Zero Sharp VRAM reads/writes and zero CEh framebuffer transfers
  - Four-interrupt frame pacing, held/multiple keys and retained short taps
  - Opening doors, walking through, and safe closing around the player
  - Dirty RAM initialization, upload mismatch and bounded busy timeout

Independent scene checks cover eight ray-depth views, partial door/sprite
occlusion, collision, blocked shots, objectives and a complete 360-frame
guided play-through. Results and hashes are in build/verification.json.

previews/boot.png and door.png are decoded from the direct CCM framebuffer
after executing both emulated CPUs. The other previews use the native C
renderer. The GIF is accelerated; RGBI colours approximate the display.

FILES

  src/raycaster.c          ARM renderer, game logic, input and native hooks
  src/host.asm             Z80 upload/call/input host and frame pacing
  src/unicard.ld           Direct framebuffer address and RAM limits
  src/unicard_header.S     OpenCPU header
  src/assets.h             Generated level, textures and sprites
  src/font.h, sine.h       Font and generated sine lookup
  tools/build.py           Compile and package the MZF
  tools/generate_assets.py Procedural assets and map validation
  tools/verify.py          Z80/ARM/direct-buffer integration checks
  tools/verify_scene.py    Independent scene checks and previews

The transport and keyboard mapping build on NOBOMI-SOFTWARE's supplied
unifractal_v0_2.mzf and the UniGray/UniCube/UniDoom work in this workspace.
