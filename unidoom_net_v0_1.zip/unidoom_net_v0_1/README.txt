UniDoom NET v0.1 — UniCard Ethernet mk3b deathmatch
================================================

Separate project based on UniDoom Direct v0.6. Load unidoom_net_v0_1.mzf.
The existing doom_direct project and its MZF are preserved.

2–4 Sharp MZ-800 machines play deathmatch, one player per machine. First to
10 frags wins. Players have separate positions, health, ammo, weapon and
scores. Opponents use animated robot sprites, coloured blue/green/red/yellow
for P1/P2/P3/P4. Walls and lifting doors block visibility and shots. Death
causes an automatic respawn after 30 simulation frames, with 30 frames of
protection; firing ends protection. Pistol hits do 25 damage; the shotgun
fires three hits. There is no friendly/enemy drone AI in deathmatch.

The complete previous single-player game remains available, including both
maps, moving drones, secrets, weapons, E1M1 music and DDQD. Cheats and the
automatic tour are disabled during deathmatch. Players can pass through
each other; collision against the level geometry remains active.

HARDWARE AND RELAY SETUP

Each machine needs a UniCard mk3b with Ethernet and firmware implementing:
  * The existing OpenCPU commands CAh..CDh.
  * The 32-bit VGA pointer published at 08008228h, as in Direct v0.6.
  * BomberNet's NET commands A0h..A9h, advertised by INFO (95h), feature
    byte 3, bit 08h. Ethernet hardware alone is insufficient.

The firmware repository supplied by the user documents the common NET
contract for MZPico. BomberNet's protocol document also describes the STM32
UniCard Ethernet implementation, emu_NET.c, and its TCP configuration.
This program uses that shared card API; it does not add/flash firmware.

1. On a PC on the same LAN, with Python 3.10 or newer:

     python3 doom_net/tools/relay.py --bind 0.0.0.0 --port 8766

   This included relay uses only Python's standard library. Keep it running.
   Alternatively use BomberNet's reference relay with TCP enabled on the LAN:
   RELAY_TCP_HOST=0.0.0.0, TCP port 8766.

2. In each UniCard's /unicard/network.cfg, set NETRELAYADDR to that PC's
   LAN IPv4 address and NETRELAYPORT to 8766, using the firmware's normal
   configuration syntax. Apply/reload the network configuration as required
   by that firmware. Both cards must reach the same PC and port.

   Use the PC's LAN address, not 127.0.0.1. The public mzpico.com relay is
   WebSocket-only; UniCard Ethernet's documented transport is TCP JSON lines.

3. Load the identical unidoom_net_v0_1.mzf on every machine.

4. One player presses H. A four-letter room code appears.
   Other players press J and type that code (BACKSPACE corrects a letter).
   Joiners press SPACE when ready. The host presses SPACE last, after the
   desired 2–4 players have joined and readied. P1 is the host.

5. ESC leaves a room or match and returns to single-player. If any player
   leaves, loses the connection or desynchronizes, the remaining machines
   stop the match and show an error; ESC exits. Create a new room to restart.

If INFO does not advertise NET, the program shows UNICARD NET FIRMWARE
REQUIRED. It remains usable offline. No firmware upgrade is bundled.

KEYS

  WASD / cursor keys    Move and turn
  Q / E                Strafe
  SPACE                Fire; in lobby, ready
  F                    Use a door / secret
  V                    Pistol / shotgun
  Z                    Walk / run
  M                    Local minimap
  L                    Local flashlight
  B                    Local music on/off
  H / J                Host / join from single-player
  ESC                  Leave / cancel
  R                    Host: rematch, preserving the selected map
  N                    Host: switch between the two different maps

Offline-only controls: R reset, 1/2 select sector, P guided tour, DDQD god
mode. A ready mask in the lobby uses bits 1,2,4,8 for P1,P2,P3,P4. The
PLAYERS value is the number of joined machines, not the number of ready bits.

The host selects the other map with N once play starts. Both maps have four
distinct valid spawn points. The map layout, doors and secret are shared;
view direction, weapon, health, ammo and running are per player. The HUD
always displays all participating players' frag scores.

Errors: 6 build mismatch; 7 room unknown/full/started; 8 not in a room;
9 relay unavailable; 10 invalid command/settings; 11 card/relay queue full;
12 ten-second timeout; 13 state desync; 14 peer dropped; 15 frame limit.
A match ends at network frame 60000 to avoid the device's 16-bit frame-wrap
limit (about an hour at the pacing ceiling). Make a fresh room afterward.

HOW IT WORKS

Z80: use the existing UniCard ports 50h/51h. REVD then INFO detects NET.
STSR (03h) reads the four-byte command status. CREATE/JOIN wait on the
IN_PROGRESS bit, bounded by 500 real 50 Hz keyboard interrupts. On error,
STORNO (04h) cancels the pending command before rendering the error screen.
The keyboard/music IRQ never touches the UniCard ports.

CREATE uses game id 5544h (UniDoom), four room slots, two input bytes per
slot, and a two-byte settings blob {protocol=1, initial_sector=0}. The build
id is the little-endian word formed from the ARM payload's first two
SHA-256 digest bytes. Different builds cannot
join each other. UniDoom and BomberNet have separate game IDs and rooms.
They share the transport, not game logic or matches.

The two input bytes are {key-down event, held-buttons mask}. NETSEND always
writes the required fixed four-byte input parameter, with two unused zero
bytes. NETPOLL consumes all four slots' two-byte vectors. Frames 0 and 1
are primed with neutral input; each later sample is sent two frames ahead.
FFFFh from NETPOLL means no frame is available and is explicitly rejected.

The Z80 uploads a 24-byte network record at ARM header offset 0Ch between
native calls. ARM advances simulation only for a new complete frame, in
fixed slot order. It moves all players first, then resolves weapons in slot
order. Simultaneous fights therefore favour the earlier slot when a lethal
hit prevents the later player firing. Rendering waits with the last shared
state until all inputs arrive; it never predicts or skips a remote input.
The slowest player limits simulation cadence. Two-frame input delay is
about 120 ms at the 16.7 FPS ceiling; actual speed depends on the hardware.

Each rendered view loads the local player's camera and state. All peers
calculate the same 16-bit state fingerprint from player state, map, doors,
sector, game frame and winner. Local camera/HUD/music and render scratch
are excluded. Every 16 network frames, NETHASH lets the relay detect a
mismatch. It stops the match on disagreement; there is no state recovery,
late joining, spectators, discovery broadcast or cross-game compatibility.

The included relay speaks the documented JSON-lines TCP protocol, forwards
opaque input, readiness and state hashes, and handles keepalive ping/pong.
It returns slots/bytes/settings in both CREATE and JOIN replies, as needed
by card firmware. It does not render, simulate the game or send video.

ARM rendering retains the validated firmware pointer at 08008228h and
accepts 10000000h..10008000h inclusive. It uses the existing double-buffered
16-colour direct VGA path. No Sharp VRAM copies or framebuffer readback.
The renderer packs its 32 cached shaded columns into 4-bit texels and shares
that storage with the BFS queue. See MEMORY.txt for the exact allocation.

SOURCES AND REFERENCES

Independent transport/relay implementation from the public protocol and
card API, with credit to MZPico/BomberNet. No BomberNet game code or assets
are included. The existing user-supplied d_e1m1.mid supplies the PSG music.

  https://github.com/MZPico/BomberNet/blob/2948cd900cf15cfd3103b70724056f2fb4e04028/docs/net-protocol.md
  https://github.com/MZPico/BomberNet/blob/2948cd900cf15cfd3103b70724056f2fb4e04028/c/common/netdev_card.c
  https://github.com/MZPico/BomberNet/blob/2948cd900cf15cfd3103b70724056f2fb4e04028/docs/setup/mz-800.md
  https://github.com/MZPico/MZPico-firmware/blob/5c7c4de63a5cc383656e23795aa98882d881cd72/docs/net-extension.md

BUILD AND VERIFICATION

From doom_net:
  make                 build root unidoom_net_v0_1.mzf
  make verify          full single-player + multiplayer emulator checks
  make verify-tcp      actual loopback TCP listener test

Needs clang for Cortex-M4, ld.lld, llvm-objcopy/llvm-nm and pasmo.
Python test dependencies are in ../requirements-dev.txt; libz80ex is also
needed. Existing /usr/local/tmp tool fallbacks are supported by the scripts.
Build inputs include ../unifractal_v0_2.mzf and ../d_e1m1.mid.
The verified toolchain uses clang/LLVM 14; the linker enforces the tight
SRAM limit if a different compiler produces a larger binary.

Verification executes the actual Z80 and Cortex-M4 machine code with a
protocol model of the NET card, plus independent native combat fixtures.
It covers two connected Z80 hosts, four ARM player states, exact native/ARM
images and hashes, rooms/readiness, stalls, duplicate frames, timeouts,
missing NET, disconnects, shots, scoring, spawning and map/rematch control.
The single-player regression additionally checks 93 host/ARM frames, both
complete guided tours, independent ray/collision/AI checks, firmware-pointer
validation and two full E1M1 PSG loops. The relay is separately exercised
through real loopback TCP sockets.

These are software/emulator results. Electrical timing, Ethernet firmware
coexistence with OpenCPU and gameplay across physical mk3b cards still need
hardware verification. If the NET-required screen appears on firmware that
already runs BomberNet, provide its version or the mk3b NET command header;
that will identify any firmware API difference.
